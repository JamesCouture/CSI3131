To compile use the next lines:

gcc  student-ta.c -o program -lpthread
./program 5

Note: in order to see the TA sleeping, a smaller number might work, like 2, the TA will go sleep